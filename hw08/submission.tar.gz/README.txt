Author: Donaven Lobo

Game: Soccer Game

Objective: 
Move the soccer ball using the arrow keys to get to the goal (the right side of the screen). 
Watch out for the goalie,as he can catch the ball and stop you from scoring.

Controls:

- Arrow Keys: Move the ball
- Start: Starts the game when at the start screen
- Select: Takes you back to the start screen at any point in the program.