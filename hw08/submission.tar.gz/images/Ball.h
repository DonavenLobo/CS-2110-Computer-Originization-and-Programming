/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 Ball Ball.jpg 
 * Time-stamp: Monday 04/04/2022, 00:13:42
 * 
 * Image Information
 * -----------------
 * Ball.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALL_H
#define BALL_H

extern const unsigned short Ball[400];
#define BALL_SIZE 800
#define BALL_LENGTH 400
#define BALL_WIDTH 20
#define BALL_HEIGHT 20

#endif

