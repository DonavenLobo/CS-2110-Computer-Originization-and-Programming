/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 Goalie Goalie.jpg 
 * Time-stamp: Monday 04/04/2022, 16:51:48
 * 
 * Image Information
 * -----------------
 * Goalie.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GOALIE_H
#define GOALIE_H

extern const unsigned short Goalie[400];
#define GOALIE_SIZE 800
#define GOALIE_LENGTH 400
#define GOALIE_WIDTH 20
#define GOALIE_HEIGHT 20

#endif

